﻿CREATE TABLE [dbo].[Adim]
(adminid VARCHAR(6),
    username VARCHAR(30),
    password VARCHAR(30),
    access_level VARCHAR(20),
    CONSTRAINT admin_adminid_pk PRIMARY KEY(adminid)
)
