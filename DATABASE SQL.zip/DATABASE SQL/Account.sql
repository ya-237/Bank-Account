﻿CREATE TABLE [dbo].[Account]
(acnumber VARCHAR(6),
    custid VARCHAR(6),
    bid VARCHAR(6),
    opening_balance VARCHAR(7),
    aod DATE,
    atype VARCHAR(10),
    astatus VARCHAR(10),
    CONSTRAINT account_acnumber_pk PRIMARY KEY(acnumber),
    CONSTRAINT account_custid_fk FOREIGN KEY(custid) REFERENCES customer(custid),
    CONSTRAINT account_bid_fk FOREIGN KEY(bid) REFERENCES branch(bid)
)
