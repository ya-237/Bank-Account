﻿CREATE TABLE [dbo].[Customer]
(custid VARCHAR(6),
    fname VARCHAR(30),
    mname VARCHAR(30),
    ltname VARCHAR(30),
    city VARCHAR(15),
    mobileno VARCHAR(10),
    occupation VARCHAR(10),
    dob DATE,

	 CONSTRAINT customer_custid_pk PRIMARY KEY(custid), 

)
